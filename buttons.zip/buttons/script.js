function changeColor(color) {
    document.body.style.backgroundColor = color;
}
