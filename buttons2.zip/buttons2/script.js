function changeColor(button) {
    if (button.classList.contains("red")) {
      button.classList.remove("red");
    } else {
      button.classList.add("red");
    }
  }
  